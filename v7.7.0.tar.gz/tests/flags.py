import sys
f = sys.argv[1]
if (f.find("-h")==0):
    print(1)
