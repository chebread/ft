USAGE:
    ft [FLAGS/<text>] [OPPTIONS/<path>]

FLAGS:
    -h, --help          Prints help information
    -V, --version       Prints version information

OPPTIONS:
    '!', (blank)        Find for a string in the currnet directory

ARGS:
    <text>              Enter text to find in files in a directory
    <path>              Enter the name of the file or the directory
