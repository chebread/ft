
USAGE:
    ft [FLAGS/<text>] [OPPTIONS/<path>]

For more information try `-h` or `--help`
