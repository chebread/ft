# Infomation
The find function of `ft` use the KMP algorithm

### Pull Requests
This blank repository

### Release
This release of `ft`

